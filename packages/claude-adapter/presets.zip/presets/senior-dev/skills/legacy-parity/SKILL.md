---
name: legacy-parity
description: Prove that a rewritten, ported, or refactored implementation reproduces the behavior of the one it replaces, including the behavior nobody documented. Use for rewrites, framework or language ports, service extraction, and any change where "same as before" is the requirement.
effort: high
---

The requirement "behave like the old one" means the old code is the
specification — including its bugs. Decide deliberately which of those bugs are
preserved and which are fixed; do not decide by accident.

## 1. Fix the reference and the tolerance

Before comparing anything, settle three things with the user or from the
requirement, in one short exchange:

- **Reference**: which implementation is the source of truth, at which version
  or commit.
- **Scope of parity**: outputs only, or side effects too — emitted events,
  written rows, external calls, logs, timing.
- **Tolerance**: what counts as equal. Exact bytes? Numbers within a rounding
  unit? Set equality ignoring order? Timestamps and generated ids normalized?
  A tolerance decided after the first mismatch is a tolerance chosen to pass.

Record known-and-accepted differences as an explicit allowlist. Anything not on
it is a defect.

## 2. Read the legacy for its accidents, not its intent

The rewrite usually reproduces the intent and loses the accidents. Look
specifically for:

- rounding: where it happens, in what order, to how many places; banker's vs
  half-up; money as float vs integer minor units;
- number and date formatting, locale, timezone, and what "today" means;
- null / empty string / zero / missing-key equivalences;
- string handling: trimming, case folding, collation, encoding, truncation at a
  fixed width;
- ordering that consumers depend on even though it was never guaranteed;
- silent failure: swallowed exceptions, defaults substituted on error, values
  clamped rather than rejected;
- ordering of side effects, and what happens when the third one fails;
- validation that is enforced by a database constraint rather than by code;
- dead branches that turn out to be reachable with production data.

Each of these is a parity question. Write down the answer the legacy gives.

## 3. Characterize before you change

When the legacy has no tests, write **characterization tests** against it first:
tests that assert what it currently does, right or wrong. They are the executable
specification, and they are what makes the rewrite reviewable.

Seed them from real inputs where possible — production-shaped rows, recorded
requests, the actual file the batch job consumed — not from invented examples,
which reproduce your assumptions rather than the system's behavior.

## 4. Compare by execution, not by reading

Reading two implementations side by side finds the differences you thought to
look for. Running both finds the others. In order of strength:

1. **Shadow / dual-run**: execute both on the same input and diff the outputs.
   Cheapest as a test harness over a fixture set; strongest as a read-only
   shadow in the real environment.
2. **Golden files**: snapshot the legacy output for a corpus of inputs, then
   assert the new implementation reproduces it.
3. **Property / differential fuzzing**: generate inputs and assert both agree.
   Worth it when the input space is large and the function is pure.
4. **Reconciliation query**: for data pipelines, compare the two output tables
   with `EXCEPT ALL` in both directions (see `sql-compare`).

Build the input corpus to include what breaks parity, not what demonstrates it:
nulls and missing fields, empty collections, duplicates, boundary values,
maximum precision, negative and zero amounts, the largest real record, dates at
month/year/DST boundaries, non-ASCII text, and inputs the legacy rejects.

## 5. Triage every difference

For each mismatch, classify before fixing:

```text
LEGACY BUG, PRESERVE      consumers depend on it — reproduce it, comment why
LEGACY BUG, FIX           user decided to fix it — needs its own note in the report
NEW BUG                   fix the new implementation
TOLERANCE                 within the agreed tolerance — record it
UNDEFINED                 legacy behavior was non-deterministic — pin it deliberately
```

A difference that cannot be classified is unresolved, not acceptable. Never
adjust the tolerance to make a mismatch disappear.

## 6. Report parity honestly

```text
Corpus:      4,812 production-shaped records, 2026-06 export
Matched:     4,796
Differences: 16
  12  rounding: legacy truncates at 2dp, new rounds half-up   -> LEGACY BUG, PRESERVED
   3  empty address renders "" vs null                        -> TOLERANCE (agreed)
   1  order of line items                                     -> NEW BUG, fixed
Not covered: refund flow (no legacy fixtures available)
```

State coverage as a fraction of the corpus you actually ran, and name what the
corpus did not contain. "Parity verified" without a corpus size and an
uncovered-area list is not a claim anyone can check.
