---
name: api-contract-review
description: Decide whether a change to an HTTP, RPC, event, or library interface breaks its consumers, and choose the compatible way to ship it - versioning, tolerant readers, deprecation. Use when a request or response shape, status code, field meaning, event payload, or published signature changes.
effort: medium
---

The question is never "is this a nicer API" but "what happens to the clients
running right now". Answer it for both directions: old client against new
server, and new client against old server, because during a deploy both exist.

## 1. Classify the change

**Safe for consumers** — adding an optional request field with a default;
adding a response field (only if consumers are tolerant readers — see below);
adding a new endpoint, method, or event type; relaxing a validation rule;
adding an enum value **to something the client only produces**, never to
something it must interpret.

**Breaking** — removing or renaming a field, endpoint, or parameter; making an
optional request field required; narrowing a type or tightening validation;
changing a status code or error shape; changing the meaning or unit of an
existing field while keeping its name; changing nullability; changing default
values; changing pagination, sort order, or limits that clients depend on;
adding an enum value the client must handle; changing authentication or scope
requirements.

**Silently breaking** — the dangerous class: same shape, different semantics.
A field that changes unit (dollars to cents), timezone, rounding, inclusivity of
a range, or which entity it refers to. Nothing in a schema diff catches these,
so they must be found by reading, and they must be shipped as a new field or a
new version, never as a redefinition.

## 2. Find the consumers

A contract review without a consumer list is a guess.

- in this repository: clients, SDKs, generated types, tests, fixtures;
- other services in the same organization: search their repos for the route,
  the event name, or the field name;
- external or unknown consumers: public endpoints, webhooks, mobile apps that
  cannot be forced to upgrade. Mobile is the hard constraint — old versions run
  for years.
- **already-serialized data**: queued messages in flight, stored event payloads,
  cached responses, webhook retries. These are consumers of the old shape that
  arrive after the deploy.

Anything you cannot enumerate is an `UNKNOWN` consumer, and `UNKNOWN` consumers
mean the change must be backward compatible or versioned.

## 3. Check the parts people forget

- **Nullability and absence**: `null`, missing key, and empty string are three
  different values to a strict client. Decide which one is emitted and keep it.
- **Error contract**: status codes, error body shape, error codes, and which
  failures are retriable. Clients branch on these, so they are part of the API.
- **Enums**: an added value breaks any client that switches exhaustively.
  Document the unknown-value behavior before adding one.
- **Pagination**: page size limits, cursor stability, total counts, and what
  happens past the end.
- **Ordering**: if the response was ordered in practice, clients depend on it
  whether or not it was specified.
- **Idempotency and retries**: which methods are safe to retry, and on which key.
- **Authorization**: a narrowed scope or a new permission check is a breaking
  change for callers that previously succeeded.
- **Field limits**: max lengths, precision, and array sizes.
- **Content type and encoding**, and date/number serialization format.

For events and queues, add: schema evolution rules of the serialization format,
consumer group replay of old messages, ordering and partitioning keys, and
whether a consumer may see the same event twice.

## 4. Ship it compatibly

Preferred, in order:

1. **Additive change with tolerant readers.** Verify the consumers actually
   ignore unknown fields before relying on it — strict deserializers and
   generated clients often do not.
2. **New field alongside the old**, both populated, old one deprecated with a
   date and a migration note for consumers.
3. **New version** — a versioned route, media type, or event type — when the
   change cannot be expressed additively. Say how long the old version is
   supported and what retires it.
4. **Coordinated breaking change** — only with an enumerable consumer list, all
   of whom are updated first. Write the deploy order down.

Never reuse a field name with a new meaning, and never reuse a removed field
name later for something else.

## 5. Verify the contract, not just the code

- a contract test or schema snapshot that fails when the shape changes;
- a test asserting the old request shape still works;
- a test for the error responses, not only the happy path;
- for events, a test deserializing a stored old-format payload;
- regenerate and diff any generated client or type — the diff is the review.

## Reporting

```text
Contract: GET /orders/{id}

BREAKING  `total` changes from dollars (float) to cents (int) with the same name
          -> ship as `total_cents`; keep `total` populated until v2 retires
SAFE      new optional `discount_code` in the response (consumers tolerant:
          web client and reporting-service ignore unknown fields — verified)
UNKNOWN   mobile app v3.x still pins /orders v1 — v1 stays until 2027-01

Verified: contract snapshot test updated; old-shape request test added.
```
