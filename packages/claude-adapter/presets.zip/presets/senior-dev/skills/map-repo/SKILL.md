---
name: map-repo
description: Derive or refresh a scoped repository instruction file (.claude/instructions/<area>.instructions.md) from repeated evidence in this codebase. Use to bootstrap repository knowledge, when `cw instructions status` reports an area STALE or MISSING, or when a task keeps rediscovering the same conventions.
argument-hint: "[area, or a path/module to map]"
effort: medium
---

Write down what a new senior engineer would otherwise have to rediscover about
one area of **this** repository. Nothing else.

Map only the area in `$ARGUMENTS`. With no argument, map the areas this
repository actually has — usually three or four, not eight.

## 1. Decide whether the file earns its place

An instruction file is worth writing when the answer to "how does this repo do
X?" is (a) repeated across the codebase, (b) not visible from a single file, and
(c) costly to get wrong. If a task can learn it from the neighboring file, stop
here and say so.

Never write a file for an area with one implementation. One occurrence is a
sample, not a convention.

## 2. Gather evidence, not impressions

Read at least three representative implementations of the area, plus the oldest
and the newest one you can find — the difference between them is where the real
convention lives. Note the paths; they become the file's `evidence` list.

For each area look for what is actually non-obvious:

- **architecture** — module boundaries, what may import what, where the
  composition root is, which directions are forbidden and why.
- **database** — where entities, repositories, and migrations live; naming;
  who opens transactions and where they end; how integration tests get a
  schema; soft delete, auditing, optimistic locking if present.
- **api** — routing and handler shape, request/response serialization,
  validation placement, error envelope, status-code conventions, auth wiring,
  pagination shape, versioning.
- **testing** — runner and invocation, unit vs integration split, fixture and
  factory conventions, what is mocked and what never is, how to run one test.
- **frontend** — state management, data fetching, component and styling
  conventions, form/validation pattern, routing, generated types.
- **logging** — logger, level policy, correlation ids, what must never be logged.
- **security** — where authorization is enforced, permission model, secret
  handling, input trust boundaries.
- **legacy** — which paths are legacy, what still calls them, what must keep
  working, what is safe to change.

Also record generated code that must not be hand-edited, and the build/test
commands the area needs.

## 3. Write it

`.claude/instructions/<area>.instructions.md`, using the frontmatter and section
contract in `.claude/instructions/README.md`:

```markdown
---
area: <area>
appliesTo: ["<glob>", "<glob>"]
updated: <YYYY-MM-DD>
evidence: ["<path>", "<path>"]
---

## Where things live
## Conventions
## Gotchas
```

Rules for the body:

- Every claim points at a real path. `Repositories live in src/repositories/`,
  not `Repositories are organized by domain`.
- Mark each rule `REQUIRED` (enforced by tooling or review), `DOMINANT` (the
  repeated pattern), `LOCAL` (true in one module), or `UNCERTAIN` (observed
  once, verify before following).
- Record contradictions instead of averaging them: "handlers in `src/api/v1`
  validate in the controller, `src/api/v2` validates in a middleware — v2 is
  newer."
- No framework tutorial, no generic best practice, nothing already in
  `CLAUDE.md`. Aim for one screen per area.

## 4. Record freshness

Update `.claude/instructions/metadata.json` so the file can be verified later:

```json
{
  "database": {
    "status": "OK",
    "last_refresh": "2026-08-31T09:12:00Z",
    "evidence": ["src/repositories/OrderRepository.ts", "migrations/2026_03_add_status.sql"]
  },
  "repo_shape": { "stacks": ["typescript", "postgres"], "services": ["api", "worker"] }
}
```

`status` is one of `OK`, `PARTIAL`, `STALE`, `UNKNOWN`. `evidence` holds
project-relative paths of files you actually read; `cw instructions status`
re-checks that each still exists and has not changed since `last_refresh`, so an
invented path makes the whole area unverifiable.

Then run `cw instructions status` and confirm the area reports `OK`.

## Refreshing

Refresh one area only when it is `MISSING`, `INVALID`, materially `STALE`, the
task enters a module the file never covered, or local code repeatedly
contradicts it. A changed evidence timestamp is a review signal — re-read the
changed file and correct the affected rule. It is not a reason to rediscover the
whole repository.

Do not modify product code.
