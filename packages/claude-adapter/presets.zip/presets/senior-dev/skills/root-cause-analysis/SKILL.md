---
name: root-cause-analysis
description: Establish the causal root cause of a defect whose cause is not visible in the code already read - wrong data with no obvious branch, intermittent or environment-dependent failures, a symptom far from its origin, or a fix that keeps not working. Use before fixing, when guessing would produce a symptom patch.
effort: high
---

Most defects do not need this. Use it when the obvious read did not produce a
cause, or when a previous fix did not hold.

The deliverable is a causal chain, not a suspicious line. "Line 42 is wrong" is
a location; "the DTO is built before the discount is applied, so any consumer of
the DTO sees the pre-discount total" is a cause.

## 1. Pin the observation

Write down, concretely: input, expected, actual, and where the difference is
first observable. "Sometimes wrong" is not an observation — find one failing
case with real values.

Then find the **narrowest reliable reproduction**: a failing test, a script, a
request with concrete parameters, or a query returning the wrong row. Fastest
first: a unit-level repro beats a manual UI walkthrough.

If it cannot be reproduced, say `NOT_REPRODUCED` and continue statically — but
only on deterministic evidence (a code path that provably produces the value, a
stored row that could only come from one branch). Never claim runtime
confirmation you do not have.

## 2. Bisect the value, not the code

Follow the wrong value backwards from where it is observed to where it was
produced. At each hop ask one question: **is the value already wrong here?**

```text
response/UI        wrong -> keep going back
serializer/DTO     wrong -> keep going back
service/domain     correct here  <- the corruption is between here and the DTO
repository/query
database/state
```

The boundary where correct becomes wrong is the cause site. This beats reading
the whole flow forward, and it terminates.

Useful bisections when the flow is not a call stack:

- **Time**: does the last known-good commit still work? `git log -S<symbol>`,
  `git bisect` when the repro is scriptable, `git blame` on the cause site.
- **Data**: does it fail for one record and not another? The difference between
  those two records is the trigger.
- **Configuration/environment**: same code, two environments, one fails — diff
  the configuration, not the code.

## 3. Separate the three layers

- **Symptom** — what the user sees.
- **Contributing factors** — what made it reachable or invisible: a missing
  constraint, a swallowed exception, a default that hides the gap, a test that
  asserts the buggy behavior.
- **Root cause** — the decision or omission that makes the wrong value
  inevitable given the inputs.

Test the causal claim before believing it: *if I change exactly this, does the
symptom have to disappear, and does anything else that currently works break?*
If you cannot answer both, the chain is incomplete.

## 4. Common shapes worth checking explicitly

Ordering (value computed before its input is ready), mutation of shared state,
stale cache or memoization, missing await / lost promise, transaction boundary
(read outside the write's transaction, rollback not covering a side effect),
type coercion and null-vs-absent, timezone/locale, rounding and integer
division, off-by-one on ranges and pagination, retry without idempotency,
partial failure leaving inconsistent state, an N+1 masked by a fixture,
concurrency between two writers of the same row.

## 5. Before fixing

Establish:

- the causal chain with `file:line` evidence at each hop;
- the smallest change that removes the cause rather than the symptom;
- **existing tests that encode the bug** — a test asserting the wrong behavior
  must be corrected deliberately, not deleted quietly;
- whether other call sites share the cause. A cause with three call sites is an
  `impact-analysis` job, not three separate patches.

Write the failing test first when the repro is automatable: it proves the cause
and becomes the regression guard.

Patch the symptom only when the symptom *is* the cause, or when the user
explicitly accepted a stopgap — and say which one it was.

## Reporting

Report the chain in three lines, not three pages:

```text
Symptom:      totals shown pre-discount on the order confirmation
Cause:        OrderDto is built in OrderController.confirm before
              DiscountService.apply mutates the order (OrderController.ts:88)
Fix:          build the DTO after apply; test added in order-confirm.test.ts
Also affected: OrderExportJob builds the same DTO at the same point (out of scope, reported)
```
