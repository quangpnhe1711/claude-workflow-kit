---
name: deep-change
description: Controlled path for a change that cannot simply be reverted - production data, destructive migration, authentication or authorization, money, or a contract with consumers outside this repository. Records one decision behind a hard gate that blocks edits until the user answers, then implements, verifies, and gets an independent adversarial review.
argument-hint: "[the change, and why it is high risk]"
effort: high
---

Use this only when the change is genuinely hard to undo. Wide is not the same as
risky: a rename across forty files is wide and reversible, so it is a normal
task. This path exists for the ones where being wrong costs data, access, money,
or a broken external consumer.

Everything else in `CLAUDE.md` still applies. This adds exactly three things: a
gate that stops the work until the decision is made, one durable record of that
decision, and an independent review that reads the diff rather than your account
of it.

## 1. Open the run

```text
cw run start deep-change --label "<short label>"
```

While `DECISION_READY` is unpassed the installed hook **denies every file edit
and every non-read-only command**. That is the point, not a malfunction:
investigate and write the decision file, then pass the gate. If `cw` is
unavailable, continue the work under the same discipline and say so once.

## 2. Investigate what makes it irreversible

`cw phase enter investigate`

Use the capability that fits — `root-cause-analysis`, `impact-analysis`,
`schema-migration`, `api-contract-review`, `legacy-parity` — and establish only
what the decision needs:

- what exactly cannot be undone, and what the recovery path costs if it is wrong;
- who and what depends on the current behavior, including consumers outside this
  repository;
- what the correct behavior is, and which part of it is a product choice rather
  than an engineering one;
- the deploy or migration order, when the change is not atomic;
- how it will be verified before anyone depends on it.

Stop when the decision can be made. `cw phase complete`.

## 3. Record the decision, then gate on it

`cw phase enter decide`

Write `<runtimeDir>/runs/<runId>/decision.md`:

```markdown
# Decision
## What is being changed and why
## What is irreversible                 <!-- and the recovery path, with its cost -->
## Impact                               <!-- consumers, data, permissions, contracts -->
## Options considered                   <!-- only real ones; say so if there was one -->
## Chosen approach and rationale
## Deploy / migration order              <!-- when not atomic -->
## Verification plan                     <!-- what proves it before anyone depends on it -->
## Open question for the user            <!-- or: none — decided from evidence -->
```

Then `cw artifact decision.md`.

**If the decision is settled by evidence** — the requirement decides it, or only
one approach is defensible — pass the gate and keep working. Do not manufacture
a question to create a checkpoint:

```text
cw gate pass DECISION_READY
```

**If a genuine product or risk decision remains**, put it to the user and wait:

```text
cw gate wait DECISION_READY --message "<the open decision>"
```

Ask in one screen — what was found, what must be decided, what you recommend and
why, the alternatives, and what is at risk either way — then stop. Call
`PushNotification` with the run id and the decision required. Only the user's
answer closes it; silence is not approval, and there is no way around the gate
that is not a lie about the state.

When the answer arrives, continue the **same** run: `cw phase enter decide`,
record the answer in `decision.md`, `cw gate pass DECISION_READY`.

## 4. Implement

`cw phase enter implement`

Smallest change that carries out the decision. Stay inside what was approved; a
finding that widens the scope goes back to step 3 rather than into the diff.

For a migration, implement the steps in the recorded order and stop at the
boundary the decision named — the destructive step is usually a later release.

`cw phase complete`

## 5. Verify

`cw phase enter verify`

Proportional to what is at risk, and biased toward evidence that would have
caught the failure mode this change creates: the migration verification queries,
the old-shape contract test, the permission negative case, the parity corpus.
Record what ran, what passed, and what is still unverified.

`cw phase complete`

## 6. Independent review

`cw phase enter review`

Delegate to the `adversarial-reviewer` agent. Pass pointers only — run
`cw review-context` and hand over its output verbatim, plus how to obtain the
diff. Never pass your own summary: a reviewer reading the implementer's account
is reviewing the account.

Persist the verdict to `review.md`, then `cw artifact review.md`. Fix
correctness findings, re-run the affected checks, and review again. Three loops
maximum; after that report the unresolved findings instead of looping.

`cw phase complete`

## 7. Finish

```text
cw run complete
```

Report as usual — Changed / Why / Verified / Not verified / Risk — plus the
decision that was made, who made it, and what the recovery path is if it turns
out to be wrong. If the user accepted a risk to proceed, say so; never present
an accepted risk as if it had been resolved.
