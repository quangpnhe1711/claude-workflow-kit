---
name: feature-analysis
description: Understand a system well enough to build a non-trivial feature into it - entry points, business flow, existing pattern to follow, data model, state transitions, transaction boundaries, consumers, permissions, compatibility, and the acceptance criteria to verification map. Use for features crossing several layers or introducing new business state, and for pre-implementation analysis requests.
effort: high
---

Depth here means understanding the system, not producing documents. Everything
below is read from the code; nothing is a form to fill in. Inspect only what is
materially relevant to this feature and say `Not relevant` for the rest.

## 1. Find the closest thing that already exists

Before designing anything, find the feature this repository already built that
is most like the requested one, and read it end to end. It answers layering,
naming, validation placement, error handling, testing, and permissions in one
pass, and it is what review will compare against.

If nothing comparable exists, that is itself the most important finding: this
feature introduces a pattern, which raises its cost and its review bar.

## 2. Trace the flow that will carry it

From the outside in, with real paths:

```text
entry point       route / handler / command / event / job / UI action
    ->  validation and authorization — where, and enforced how
    ->  service / domain logic — where business rules actually live
    ->  persistence — repository, query, transaction boundary
    ->  side effects — events, queues, notifications, external calls
    ->  response / projection — DTO, serializer, cache
```

Name the file for each hop. A hop you cannot name is a hop you have not read.

## 3. Establish what the feature actually needs

Only the ones that apply:

- **Data model** — new fields/tables, or reuse of existing ones. Nullability and
  defaults for rows that already exist. Migration shape (see `schema-migration`).
- **State transitions** — the legal states, who may move between them, what is
  forbidden, what happens on the illegal transition. Draw it if there are more
  than three.
- **Transaction boundaries** — what must commit together; what is outside the
  transaction and can therefore fail independently (emails, events, external
  calls); what happens on partial failure.
- **Concurrency and idempotency** — only when two actors can act on the same
  entity, or a caller can retry: duplicate submissions, double-click, webhook
  redelivery, job re-run. Decide the key that makes the operation idempotent.
- **Permissions** — who may do it, enforced at which layer, and how the existing
  code expresses that. Include the negative case.
- **Error behavior** — what the user sees, what is retried, what is logged, what
  the API returns.
- **External integrations** — contract, failure mode, timeout, and whether the
  feature can be correct while the integration is down.
- **Consumers and compatibility** — who reads what this changes; whether old
  clients and old rows keep working (see `impact-analysis`,
  `api-contract-review`).

## 4. Resolve behavior before designing

List the behavioral questions the requirement leaves open. For each, decide
whether evidence answers it — the request, acceptance criteria, an existing
rule in code, a comparable feature — or whether it is a genuine product choice.

Ask the user only about genuine product choices that change data, permissions,
money, state, or a contract, and ask them together, once. Record the others as
one-line assumptions and continue.

## 5. Acceptance criteria to verification

The output that makes this skill worth running. One row per criterion:

```text
AC1  retry must not create duplicate orders
     code path:    OrderService.submit (idempotency key = requestId)
     verification: integration test — same requestId twice, one row

AC2  only the owner may cancel
     code path:    OrderPolicy.canCancel + controller guard
     verification: unit test, owner and non-owner
```

A criterion with no verification is not done; a verification with no criterion
is a test nobody asked for. Carry this list to the end of the task and report
each as `VERIFIED` or `NOT VERIFIED` with the reason.

## 6. Choose the approach

Compare options only when genuinely different approaches exist — two credible
designs with different trade-offs. Then state, briefly: what each costs, what
each risks, what fits the existing pattern, and which you recommend and why.

When one approach obviously fits the repository's pattern, say so in a line and
proceed. Manufacturing three options to look thorough wastes the user's time.

## Output

Normally this stays in the conversation: the flow, the decisions, the
assumptions, the AC-to-verification map, then implementation.

Write a document only when the user asked for analysis without code, or the
result must survive the session. In that case follow
`.claude/prompts/analysis-report.prompt.md`, and stop before implementing.
