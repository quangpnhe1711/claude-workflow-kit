---
name: performance-investigation
description: Find why something is slow by measuring it, then prove the fix changed it - baseline, profile, locate the dominant cost, fix, re-measure. Use for slow endpoints, queries, jobs, builds, or page loads, and whenever an optimization is proposed without a measurement behind it.
effort: medium
---

An optimization without a before-and-after number is a guess that costs
readability. The whole method is: measure, locate, fix the dominant cost,
measure again.

## 1. State the target

"Slow" is not actionable. Establish, before touching anything:

- **What** is slow: one endpoint, one query, a page, a job, the test suite.
- **How slow, at which percentile**: p50 and p95/p99 are different problems.
  A p99 caused by lock contention will not appear in a p50 measurement.
- **At what scale**: rows, concurrent users, payload size. Most performance bugs
  are invisible at development scale and obvious at production scale.
- **What "fixed" means**: a number and a workload. Without it, the work has no
  stopping point.

## 2. Baseline, reproducibly

Measure the current state before changing anything, with production-shaped data.
A 20-row development table hides every N+1 and every missing index.

Keep the measurement honest: warm up first, repeat and report the distribution
rather than one run, hold the environment fixed, and measure the same thing each
time. Note what you cannot control.

Cheap and usually sufficient: time the operation end to end, then time the
suspected span inside it, and see whether they are the same number.

## 3. Locate the dominant cost — do not guess

Use the tool that reports where time actually goes: a profiler, the framework's
request timing, `EXPLAIN ANALYZE` for a query, the browser performance panel,
build-tool tracing. If none is available, bisect by timing spans.

Then answer one question: **what fraction of the total is the largest single
cost?** Optimizing anything else is wasted work until that changes.

Look for the shapes that account for most real slowness:

- **N+1**: one query per row. Count queries per request; the count should not
  scale with result size.
- **Missing or unused index**: `EXPLAIN` shows a sequential scan or a wrong
  index. Check that the predicate is sargable — a function or cast on the
  indexed column disables the index.
- **Over-fetching**: selecting every column and every relation, then using two
  fields; loading the whole table to filter in application code; pagination that
  counts all rows on every page.
- **Serial I/O**: independent calls awaited one at a time.
- **Repeated work**: the same computation or request inside a loop; a cache that
  is missed because the key includes something volatile.
- **Lock contention and connection-pool waiting** — the classic p99 cause, which
  looks like fast code that sometimes takes 3 seconds.
- **Algorithmic**: quadratic scans over a list, a nested loop over two
  collections that should be a hash join.
- **Payload size**: uncompressed responses, unbounded result sets, large images.

Constant-factor micro-optimization is last, and usually not worth the
readability it costs.

## 4. Fix the dominant cost only

Change one thing at a time and re-measure between changes; two simultaneous
fixes make the measurement uninterpretable. Prefer, in order: do less work
(fewer rows, fewer round trips, fewer calls), do it once (cache/batch/prefetch),
then do it faster.

Every cache added is a correctness question: what invalidates it, what is stale
in the meantime, and who else writes the underlying data. If that cannot be
answered, the cache is a bug in waiting.

Stop at the target. Continuing past it trades maintainability for a number
nobody needs.

## 5. Prove it

Report the before and after under the same workload, with the change in
context:

```text
GET /orders?status=open   p95, 5k-order tenant, 20 runs

before  1,840 ms   142 queries (N+1 on order.customer)
after     96 ms      3 queries (batched customer load)

Correctness: order-list tests pass; response body byte-identical on the
             fixture set.
Not measured: p99 under concurrency — single-client benchmark only.
```

Always include what the change might have broken and how that was checked. A
performance fix that changes results is a defect with a good benchmark.
