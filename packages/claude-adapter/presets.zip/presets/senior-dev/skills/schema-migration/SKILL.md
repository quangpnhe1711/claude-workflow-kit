---
name: schema-migration
description: Plan and verify a database schema or data migration that cannot be undone by reverting code - column and table changes, backfills, type and constraint changes, renames, and deletions - including the deploy sequence, locking behavior, and rollback path. Use whenever a change touches DDL or rewrites existing rows.
effort: high
---

Code changes revert. Migrations do not. Everything here follows from that.

## 1. Classify the migration

| Class | Examples | Deploy shape |
| --- | --- | --- |
| **Additive** | nullable column, new table, new index | one step, safe |
| **Expand** | new column that will replace an old one | expand, then migrate, then contract |
| **Tightening** | NOT NULL, new unique/FK constraint, narrower type | requires the data to already comply |
| **Destructive** | drop column/table, rename, type change losing precision | never in one step |
| **Data-only** | backfill, correction, reshaping | separate from DDL |

Anything past additive uses **expand / migrate / contract**, in separate
deployments:

```text
1. expand    add the new shape; write to both; read from the old
2. migrate   backfill in batches; verify counts and values
3. switch    read from the new shape; keep the old written
4. contract  stop writing the old; drop it — a later release, once rollback
             to before step 3 is no longer needed
```

Renames are expand/contract, never `ALTER ... RENAME` on a live table: a rename
breaks every running instance of the old code at once.

## 2. Establish the deploy invariant

At every instant during rollout, both the old and the new application version
may be running against the same database. Write down what each does, for each
step. A migration is correct only if:

- the old code still works against the new schema (until it is retired), and
- the new code works against the old schema (until the migration lands),

or the deploy is explicitly ordered and gated, and you say so.

This is what makes "add the column NOT NULL with a default" a bad first step and
"add nullable, backfill, then set NOT NULL" a good one.

## 3. Check the locking behavior of every statement

The same DDL is instant on one engine and a full-table rewrite on another, and
a rewrite on a large hot table is an outage. Before writing the migration,
establish for this engine and version:

- which `ALTER` forms rewrite the table or hold an exclusive lock;
- whether index creation can be concurrent / online, and what that costs;
- whether adding a constraint validates existing rows under a lock, and whether
  it can be added `NOT VALID` and validated separately;
- the lock queue: a blocked DDL statement blocks every query behind it, so a
  short lock on a busy table is not necessarily short;
- statement and lock timeouts, and whether the migration runner sets them.

State what you found for the target engine rather than assuming. If it cannot
be established, say so and treat the statement as blocking.

## 4. Backfill as a batched, resumable job

Never `UPDATE` a large table in one transaction: it holds locks, bloats the log,
and cannot be resumed.

- batch by primary key range, bounded size, committed per batch;
- idempotent — re-running a batch must not double-apply;
- resumable — record progress; a killed job restarts where it stopped;
- throttled — pause on replication lag or lock waits;
- covered by the application's dual-write, so rows changing during the backfill
  are not missed;
- verifiable — a query that counts rows still needing work must reach zero.

## 5. Decide the rollback path before deploying

For each step, write the answer:

- **Additive**: revert code; the column stays. Harmless.
- **Expand/migrate**: revert code; the new column keeps being written or goes
  stale — say which, and whether re-running the backfill fixes it.
- **Contract/destructive**: there is no rollback. The recovery path is a restore
  or a re-derivation, and both have a cost and a data-loss window. Name them.

If the honest answer is "restore from backup", verify that a restore is actually
practiced, and treat the step as a decision the user must make (`deep-change`).

## 6. Verify with queries, not with hope

Before contract, and before calling the migration done:

```sql
-- nothing left to backfill
SELECT count(*) FROM t WHERE new_col IS NULL AND <needs backfill>;
-- old and new agree
SELECT count(*) FROM t WHERE new_col IS DISTINCT FROM <expression over old cols>;
-- constraint would hold
SELECT count(*) FROM t WHERE <the constraint about to be added> IS NOT TRUE;
```

Also verify: the migration runs on a copy of production-shaped data, not an
empty test schema; it is re-runnable; row counts before and after are what you
predicted; and application tests pass against both the pre- and post-migration
schema for the steps where both must work.

## 7. The rest of the blast radius

A schema change is rarely only a schema change. Check, and report:
ORM models and generated types; raw SQL and reporting queries; views, triggers,
functions, and materialized views; indexes that the new predicate needs and old
indexes that are now dead weight; foreign keys in both directions; replicas,
ETL, CDC consumers, and data warehouse schemas; fixtures and seed data; backup
and restore scripts that enumerate columns.

## Reporting

```text
Migration: orders.total_cents replaces orders.total (float -> bigint minor units)

Step 1 (this PR)  add total_cents nullable; dual-write in OrderService
                  lock: metadata only, safe on 40M rows
Step 2            backfill in 10k batches, resumable; ~25 min; verify query below
Step 3            switch reads; keep dual-write
Step 4 (next release) drop orders.total  -- NO ROLLBACK past this point

Rollback: steps 1-3 revert with code only. Step 4 requires restore.
Verified: migration run on a 2026-08 production snapshot; 0 rows mismatched.
```
