---
name: sql-compare
description: Decide whether two SQL statements return the same result, and characterize every difference that remains - projection, join semantics, predicate and NULL handling, grouping, ordering, pagination, parameter binding, and vendor dialect differences. Use when rewriting, optimizing, porting, or migrating a query, or when comparing a legacy query against its replacement.
effort: high
---

"Looks equivalent" is the failure mode this exists to prevent. Two queries are
equivalent only if they produce the same **multiset of rows** for every legal
input, not just for the row you tried.

Work through the checklist in order and record each item as `SAME`,
`DIFFERENT (<consequence>)`, or `UNKNOWN (<what would settle it>)`.

## 1. Normalize before comparing

Rewrite both statements into the same shape so real differences stand out:

- expand `SELECT *` to the actual column list from the schema;
- qualify every column with its table, and resolve aliases to base tables;
- rewrite implicit joins (`FROM a, b WHERE a.id = b.a_id`) as explicit `JOIN`;
- inline or name CTEs and subqueries consistently;
- normalize literal formatting, keyword case, and whitespace;
- resolve `USING (x)` to `ON a.x = b.x` — note that `USING` collapses the two
  columns into one in the projection.

Do not "simplify" during normalization. Preserve parentheses exactly:
`a AND b OR c` is not `a AND (b OR c)`.

## 2. Projection

- Same columns, same order, same names? A renamed alias breaks consumers that
  read by name; a reordered projection breaks consumers that read by index.
- Same types after expression changes? `SUM(int)` vs `SUM(numeric)`,
  `COUNT(*)` (bigint) vs `COUNT(col)`, integer division vs decimal division,
  implicit casts in concatenation.
- `DISTINCT` present in one and not the other — check whether the join shape
  made it unnecessary, or whether it was hiding duplicates.

## 3. Join semantics

The most common source of silent difference:

- **Join type**: `INNER` vs `LEFT` changes the row count whenever the right
  side is missing. A `LEFT JOIN` whose right-side column appears in the `WHERE`
  clause (`WHERE r.status = 'x'`) is an `INNER JOIN` in disguise — the predicate
  must move into `ON` to stay outer.
- **Cardinality**: a join to a one-to-many table multiplies rows. Check whether
  one query de-duplicates (`DISTINCT`, `GROUP BY`, a `LIMIT 1` subquery,
  `DISTINCT ON`, a window function) and the other relies on the join being
  unique. Verify uniqueness against the schema's keys, not against sample data.
- **ON vs WHERE placement** for outer joins changes results; for inner joins it
  does not.
- `EXISTS` vs `IN` vs `JOIN`: `EXISTS` and `IN` do not multiply rows, `JOIN`
  does. `NOT IN` with a NULL in the subquery returns no rows at all;
  `NOT EXISTS` does not have that behavior. This is a real bug, not a nuance.
- Semi/anti-join rewrites must preserve the "at least one" vs "exactly one"
  meaning.

## 4. Predicates and NULL semantics

- Three-valued logic: `NULL = NULL` is unknown; `x <> 'a'` excludes rows where
  `x IS NULL`; `NOT (x > 5)` is not `x <= 5` when `x` is nullable.
- A rewritten `OR` chain into `IN`, or `IN` into a join, must preserve NULL
  behavior.
- `COALESCE` added or removed changes which rows match and what aggregates count.
- Range predicates: `BETWEEN` is inclusive on both ends; a date range compared
  with `<= end_date` includes or excludes the whole last day depending on
  whether the column is date or timestamp.
- Type coercion in comparisons: string-to-number, timestamp-to-date, collation
  and case sensitivity, trailing-space semantics (`CHAR` vs `VARCHAR`).
- Timezone: `AT TIME ZONE`, session timezone, `NOW()` vs `CURRENT_DATE`, and
  whether the two queries bucket days in the same zone.

## 5. Aggregation and grouping

- Same `GROUP BY` key set? An extra key splits groups; a missing one merges them.
- `COUNT(*)` counts rows; `COUNT(col)` skips NULLs; `COUNT(DISTINCT col)` is a
  third thing. `SUM` of no rows is NULL, not 0 — check whether one query
  wraps it in `COALESCE`.
- `HAVING` vs `WHERE`: moving a predicate across the aggregation changes the
  aggregate's inputs.
- Grouping applied before vs after a join changes the values being aggregated —
  the classic fan-out double-count.
- Window functions: same `PARTITION BY`, same `ORDER BY`, and the same frame.
  A default frame (`RANGE UNBOUNDED PRECEDING`) differs from `ROWS` when the
  order key has ties.

## 6. Ordering, limits, and pagination

- `ORDER BY` differences only matter to the consumer — but they matter a lot
  when combined with `LIMIT`. Without a total order, `LIMIT` picks arbitrarily
  among ties, so two "equivalent" paginated queries can return different rows.
- NULL ordering differs by vendor (`NULLS FIRST/LAST` defaults).
- `OFFSET` vs keyset pagination give different results under concurrent writes.

## 7. Parameters and binding

- Same parameter count, order, and types. A positional rewrite that reorders
  `$1`/`?` is a runtime bug the SQL text alone hides.
- A parameter used twice in one query and once in the other.
- List parameters: `IN (?)` expanded by the driver vs `= ANY($1)`.
- Empty-list behavior: `IN ()` is a syntax error in most vendors; the code path
  that builds the query must handle it identically.
- Injected string interpolation on either side is a defect to report regardless
  of equivalence.

## 8. Dialect differences

When the two statements target different vendors, check at minimum: identifier
quoting and case folding; `LIMIT/OFFSET` vs `TOP` vs `FETCH FIRST`; string
concatenation (`||` vs `+` vs `CONCAT`); `ISNULL`/`NVL`/`IFNULL` vs `COALESCE`;
date arithmetic and truncation; integer division; boolean type vs 0/1; empty
string vs NULL (Oracle); `GROUP BY` permitting unaggregated columns (MySQL
without `ONLY_FULL_GROUP_BY`); default collation and case sensitivity;
`MERGE`/upsert syntax.

## 9. Prove it, do not argue it

Reasoning finds the candidate differences; execution settles them. When a
database is reachable:

```sql
-- rows in A not in B, and rows in B not in A; both must be empty
(SELECT ... FROM a_query EXCEPT ALL SELECT ... FROM b_query)
UNION ALL
(SELECT ... FROM b_query EXCEPT ALL SELECT ... FROM a_query);
```

`EXCEPT ALL` (or `MINUS`) preserves multiplicity, so it catches duplicate-row
differences that `EXCEPT` hides. Compare `COUNT(*)` and per-column checksums as
a cheap first pass. Run it against data that contains the awkward cases: NULLs
in join keys, duplicate children, boundary dates, empty parameter lists, and the
largest and smallest values in range.

Compare execution plans only for a performance question — a plan difference is
not a correctness difference.

## Reporting

State a verdict, then the evidence:

```text
Verdict: NOT EQUIVALENT

1. LEFT JOIN payments + WHERE p.status='paid' (new) drops unpaid orders
   that the old INNER-free query returned.       -> row loss, HIGH
2. SUM(amount) returns NULL for empty groups in the new query; the old one
   wrapped it in COALESCE(...,0).                -> report shows blank, MEDIUM
3. ORDER BY created_at is not a total order; with LIMIT 50 the page contents
   differ between runs.                          -> pagination instability, MEDIUM

Verified by: EXCEPT ALL both directions on staging (2026-08-30) — 143 rows
             returned only by the old query.
```

Never report `EQUIVALENT` on reading alone when the data was reachable and you
did not run the comparison. Say `EQUIVALENT BY ANALYSIS — not executed` instead.
