---
name: impact-analysis
description: Find everything a change actually breaks before making it - consumers, contracts, jobs, exports, caches, permissions - and turn that into the regression checks worth running. Use when the code being changed is shared, when a signature/shape/semantic changes, or when a fix must not disturb behavior something else depends on.
effort: medium
---

The point is to find the consumers you would otherwise discover in production,
then stop. This is a bounded search with a termination rule, not an audit.

## 1. Name the change precisely

Impact follows from what kind of change it is:

| Change | What can break |
| --- | --- |
| signature or type | every caller — the compiler finds them |
| **semantics with the same signature** | every caller — nothing finds them but you |
| return shape / serialization | API clients, snapshot tests, exports, stored payloads |
| stored data shape or meaning | old rows, backups, replicas, downstream reports |
| default value or configuration | environments that never set it |
| timing / ordering / transaction boundary | concurrent writers, retries, jobs |
| permission or visibility rule | every screen and query that assumed the old one |
| removal | anything not statically linked: config, reflection, SQL, strings |

Same-signature semantic changes are the dangerous row: type checking says
nothing, so the search below is the only defense.

## 2. Find consumers by evidence

Static first, then the paths static analysis cannot see:

```bash
grep -rn "<symbol>"                       # direct references
grep -rn "<route>\|<table>\|<column>"     # string-addressed usage
grep -rni "<feature-name>"                # config keys, feature flags, translations
```

Then check, for what the change touches, each of these that exists in this repo:

- other call sites of the same function, and subclasses/implementations;
- HTTP or RPC clients of a changed endpoint, including other services;
- background jobs, schedulers, queue consumers, webhooks;
- reports, exports, dashboards, analytics events;
- caches keyed on the old shape, and anything already serialized: sessions,
  queued messages in flight, stored JSON columns, event logs;
- migrations and seed/fixture data;
- tests that assert the current behavior — each is a consumer with an opinion.

For a database change also list: indexes, views, triggers, foreign keys, and
raw SQL anywhere in the codebase.

## 3. Classify what you found

```text
DIRECT      must change with this diff
INDIRECT    behaves differently after this diff, and is not being changed
SAFE        references it, unaffected — say why in a few words
UNKNOWN     cannot be determined from this repository (external consumer, dynamic dispatch)
```

`UNKNOWN` is a real answer and belongs in the report. `SAFE` with no reason is
a guess.

## 4. Stop

Stop when every direct consumer is accounted for and every indirect one is
either handled, verified, or reported. Do not widen into modules that only
neighbor the change. Do not open the codebase's architecture because a shared
helper was touched.

## 5. Turn impact into checks

Impact analysis is worthless if it does not change what you run. Map each
INDIRECT item to the cheapest check that would catch its regression:

```text
INDIRECT  OrderExportJob reads total from the same DTO
          -> existing test order-export.test.ts covers it: run it
INDIRECT  reporting service consumes /orders response shape
          -> no test in this repo; contract kept backward compatible; noted as UNKNOWN-verified-by-shape
```

Run those checks, not the full suite. If an indirect consumer has no test and no
cheap check, say so explicitly rather than implying coverage.

## Reporting

```text
Impact:
  DIRECT    OrderController.confirm, OrderDto (changed)
  INDIRECT  OrderExportJob (verified by order-export.test.ts)
  UNKNOWN   reporting-service consumes /orders v1 (shape unchanged; not testable here)
```

Keep it to the lines that matter. An impact list nobody acts on is paperwork.
